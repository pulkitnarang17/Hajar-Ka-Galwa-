# CleanAir Route — v2

A pollution-aware route finder. Pick a start and a destination, and it compares several routes by how much polluted air you would breathe on each one, then recommends the cleanest practical option for who is travelling and when.

**Everything is free and key-less:** Leaflet + CARTO/OpenStreetMap tiles, OSRM public server for routes, Nominatim for place search. Air quality is **simulated** (no real measurements) — it is an illustration.

## What's new in v2

- **Time of day:** a slider (12 am to 11:30 pm) changes the pollution. Traffic zones peak at rush hour, industry in the daytime, markets in the evening. The heatmap and all scores update live.
- **Best time to leave:** a 24-hour chart for the selected route, with the cleanest hour highlighted. Tap a bar to travel then.
- **Trip simulation:** press "Simulate trip" to watch a marker travel the route while a live HUD shows current AQI and how much of the trip's exposure has built up. Speed 1×, 2×, 4×.
- **AQI profile chart:** AQI against distance for every route. Hover or tap to scrub along the route.
- **Health snapshot:** average PM2.5, minutes in Poor air, a cigarette-equivalent estimate, the worst stretch and advice tailored to the profile and travel mode.
- **Polish:** dark mode, mobile-friendly layout, and a short first-visit tour (the ? button replays it).

## Run it

No build step. Open the folder in VS Code and use **Live Server** ("Go Live"), or:

```bash
npx serve .          # or: python -m http.server 8000
```

Needs internet for map tiles and routing.

## How it works

1. Fetch several candidate routes (OSRM alternatives, plus detours via points swung to each side).
2. Cut each route into ~150 m segments and read the simulated AQI at each segment for the chosen time of day.
3. For each segment: `effective AQI × minutes spent × breathing rate`. AQI above the profile's threshold is penalised more steeply.
4. Sum to an exposure score. Recommend the lowest-exposure route within the profile's accepted extra travel time.

| Setting | Effect |
| --- | --- |
| Normal | Penalty starts at AQI 100, accepts up to +15% travel time |
| Sensitive | Penalty starts at AQI 50, steeper penalty, accepts up to +40% travel time |
| Car / Cycle / Walk | Scales inhaled pollution per minute (car 0.5, walk 1.0, cycle 1.8) and sets speed for walk and cycle |
| Scenario | Typical day, smog / stubble-burning season, or clean day |
| Time of day | Scales each zone type by its daily rhythm (see `aqiField.js`) |

Routes are always road routes from OSRM's public demo server; walk and cycle change speed and exposure, not the path.

## Project layout

```
index.html
css/style.css
js/
  profiles.js   who is travelling + travel modes (config only)
  aqiField.js   simulated pollution: getAQI(lat, lng), hotspots, time of day, colours
  geo.js        distance + polyline resampling helpers
  scoring.js    exposure maths, ranking, hourly exposure, warnings
  health.js     PM2.5, cigarette-equivalent, risk level, advice
  routing.js    Nominatim search + OSRM routes (+ offline fallback)
  chart.js      AQI-vs-distance SVG chart
  playback.js   trip animation engine
  map.js        Leaflet: heatmap layer, markers, route drawing, trip marker
  tour.js       first-visit walkthrough
  main.js       UI wiring
```

All modules share one global namespace, `window.CARF`, so the app works from a plain file open with no bundler.

## Merging into the main project

- **Swap the data source:** `getAQI(lat, lng)` in `aqiField.js` is the only function that provides pollution data. Re-implement it on top of the main AQI simulator (or a real API such as WAQI / OpenAQ). If your source has no time-of-day model, keep `C.setHour` / `C.getHour` as no-ops and the rest keeps working; with a live feed, the "best time to leave" chart should be hidden or fed with forecast data.
- Hotspot positions are approximate and illustrative, centred on Ludhiana. Outside that area the field is a flat background level. To move the demo to another city, edit `C.CITY` and `C.HOTSPOTS`.
- If the main project uses ES modules or a framework, each file is a small self-contained unit: convert `C.xyz = …` assignments to exports.

## Notes and limits

- The OSRM and Nominatim public servers are for light/demo use. If routing is unreachable, the app falls back to illustrative curved paths and says so.
- The exposure score is a relative comparison between routes, not a medical dose. The cigarette-equivalent figure uses the common rule of thumb of 22 µg/m³ PM2.5 over 24 h ≈ 1 cigarette and is illustrative only.
- The hourly pattern is a simple, made-up daily rhythm for demonstration, not measured data.

## Git

```bash
git init
git checkout -b feature/clean-route-finder-v2
git add .
git commit -m "Add clean air route finder v2"
git remote add origin <your-repo-url>
git push -u origin feature/clean-route-finder-v2
```
