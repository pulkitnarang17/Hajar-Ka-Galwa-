/* routing.js — place search (Nominatim) and route fetching (OSRM public demo server).
 * Both are free and need no API key. If routing is unreachable, syntheticRoutes()
 * produces illustrative curved paths so the demo still works offline. */
(function (G) {
  const C = (G.CARF = G.CARF || {});
  const OSRM = 'https://router.project-osrm.org/route/v1/driving/';

  function timedFetch(url, ms) {
    const ctl = new AbortController();
    const timer = setTimeout(function () { ctl.abort(); }, ms || 15000);
    return fetch(url, { signal: ctl.signal }).finally(function () { clearTimeout(timer); });
  }

  // ---- place search ----
  C.geocode = async function (query, bounds) {
    let url = 'https://nominatim.openstreetmap.org/search?format=json&limit=5&q=' + encodeURIComponent(query);
    if (bounds) {
      url += '&viewbox=' + [bounds.getWest(), bounds.getNorth(), bounds.getEast(), bounds.getSouth()].join(',');
    }
    const res = await timedFetch(url, 10000);
    if (!res.ok) throw new Error('Search failed (' + res.status + ')');
    const data = await res.json();
    return data.map(function (d) {
      return { label: d.display_name, lat: parseFloat(d.lat), lng: parseFloat(d.lon) };
    });
  };

  // ---- routes ----
  function toRoute(r) {
    return {
      coords: r.geometry.coordinates.map(function (c) { return [c[1], c[0]]; }),
      distance: r.distance,
      duration: r.duration
    };
  }

  async function osrm(points, alternatives) {
    const path = points.map(function (p) { return p.lng + ',' + p.lat; }).join(';');
    const url = OSRM + path + '?overview=full&geometries=geojson' + (alternatives ? '&alternatives=3' : '');
    const res = await timedFetch(url, 15000);
    if (!res.ok) throw new Error('Routing failed (' + res.status + ')');
    const data = await res.json();
    if (data.code !== 'Ok' || !data.routes.length) throw new Error('No route found');
    return data.routes.map(toRoute);
  }

  // true if `cand` mostly lies on top of an already-collected route
  function isDuplicate(cand, list) {
    const cs = C.resample(cand.coords, 250);
    return list.some(function (r) {
      const rs = C.resample(r.coords, 60);
      let near = 0;
      cs.forEach(function (p) {
        for (let i = 0; i < rs.length; i++) {
          if (C.haversine(p, rs[i]) < 90) { near++; break; }
        }
      });
      return near / cs.length >= 0.85;
    });
  }

  C.fetchRoutes = async function (a, b) {
    const routes = await osrm([a, b], true);

    // The public server often returns only 1–2 alternatives, so we also ask for
    // detours via points swung out to each side of the straight line.
    const mid = { lat: (a.lat + b.lat) / 2, lng: (a.lng + b.lng) / 2 };
    const dx = b.lng - a.lng;
    const dy = b.lat - a.lat;
    const k = 0.22;
    const vias = [
      { lat: mid.lat + dx * k, lng: mid.lng - dy * k },
      { lat: mid.lat - dx * k, lng: mid.lng + dy * k }
    ];
    const extra = await Promise.all(vias.map(function (v) {
      return osrm([a, v, b], false).catch(function () { return []; });
    }));

    extra.forEach(function (list) {
      list.forEach(function (r) {
        if (routes.length < 5 && r.distance < routes[0].distance * 1.8 && !isDuplicate(r, routes)) {
          routes.push(r);
        }
      });
    });
    return routes;
  };

  // Offline fallback: straight line plus two curved detours.
  C.syntheticRoutes = function (a, b) {
    const mid = { lat: (a.lat + b.lat) / 2, lng: (a.lng + b.lng) / 2 };
    const dx = b.lng - a.lng;
    const dy = b.lat - a.lat;
    return [0, 0.18, -0.18].map(function (k) {
      const ctrl = { lat: mid.lat + dx * k * 2, lng: mid.lng - dy * k * 2 };
      const coords = [];
      for (let i = 0; i <= 40; i++) {
        const t = i / 40;
        const u = 1 - t;
        coords.push([
          u * u * a.lat + 2 * u * t * ctrl.lat + t * t * b.lat,
          u * u * a.lng + 2 * u * t * ctrl.lng + t * t * b.lng
        ]);
      }
      const distance = C.pathLength(coords) * 1.25;
      return { coords: coords, distance: distance, duration: distance / (28 / 3.6) };
    });
  };
})(typeof window !== 'undefined' ? window : globalThis);
