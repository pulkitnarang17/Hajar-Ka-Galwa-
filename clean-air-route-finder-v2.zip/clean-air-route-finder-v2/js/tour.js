/* tour.js — short first-visit walkthrough. Highlights a part of the page and explains it. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  const STEPS = [
    { target: '#startField', title: 'Pick your trip',
      text: 'Search a place, click the map, or try one of the demo buttons. Pins can be dragged afterwards.' },
    { target: '#profileSeg', title: 'Who is travelling?',
      text: 'Sensitive travellers get stricter limits and are offered longer detours for cleaner air. Car, cycle and walk change how much pollution is inhaled.' },
    { target: '#timeSlider', title: 'When are you leaving?',
      text: 'Slide through the day. The heatmap and every score update live, since traffic and industry follow daily rhythms.' },
    { target: '#results', title: 'Compare, simulate, decide',
      text: 'Compare routes, press "Simulate trip" to watch your exposure build up, read the health snapshot, and check the best time to leave.' }
  ];

  let i = 0, card = null, hl = null;

  function clearHl() {
    if (hl) hl.classList.remove('tour-hl');
    hl = null;
  }

  function end() {
    clearHl();
    if (card) card.style.display = 'none';
    try { localStorage.setItem('carf_tour_done', '1'); } catch (e) { /* ignore */ }
  }

  function show() {
    if (!card) {
      card = document.createElement('div');
      card.className = 'tour';
      card.setAttribute('role', 'dialog');
      card.setAttribute('aria-label', 'Quick tour');
      document.body.appendChild(card);
    }
    const s = STEPS[i];
    clearHl();
    const el = document.querySelector(s.target);
    if (el) {
      hl = el.closest('section') || el;
      hl.classList.add('tour-hl');
      hl.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
    const last = i === STEPS.length - 1;
    card.innerHTML =
      '<div class="tour-step">Step ' + (i + 1) + ' of ' + STEPS.length + '</div>' +
      '<h4>' + s.title + '</h4><p>' + s.text + '</p>' +
      '<div class="tour-actions"><button type="button" class="tour-skip">Skip</button><span class="spacer"></span>' +
      (i > 0 ? '<button type="button" class="tour-back">Back</button>' : '') +
      '<button type="button" class="tour-next">' + (last ? 'Done' : 'Next') + '</button></div>';
    card.style.display = 'block';
    card.querySelector('.tour-skip').addEventListener('click', end);
    card.querySelector('.tour-next').addEventListener('click', function () {
      if (last) end(); else { i++; show(); }
    });
    const back = card.querySelector('.tour-back');
    if (back) back.addEventListener('click', function () { i--; show(); });
  }

  C.Tour = {
    start: function () { i = 0; show(); },
    shouldAutoStart: function () {
      try { return !localStorage.getItem('carf_tour_done'); } catch (e) { return true; }
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
