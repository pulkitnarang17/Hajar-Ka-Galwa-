/* geo.js — small geometry helpers. Points are [lat, lng]. */
(function (G) {
  const C = (G.CARF = G.CARF || {});
  const R = 6371000;
  const rad = Math.PI / 180;

  // great-circle distance in metres
  C.haversine = function (a, b) {
    const dLat = (b[0] - a[0]) * rad;
    const dLng = (b[1] - a[1]) * rad;
    const s = Math.sin(dLat / 2) ** 2 +
      Math.cos(a[0] * rad) * Math.cos(b[0] * rad) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(s));
  };

  C.pathLength = function (coords) {
    let d = 0;
    for (let i = 1; i < coords.length; i++) d += C.haversine(coords[i - 1], coords[i]);
    return d;
  };

  // points spaced roughly stepM metres apart along the polyline (ends included)
  C.resample = function (coords, stepM) {
    const out = [coords[0]];
    let carry = 0;
    for (let i = 1; i < coords.length; i++) {
      const a = coords[i - 1];
      const b = coords[i];
      const d = C.haversine(a, b);
      if (d === 0) continue;
      let pos = stepM - carry;
      while (pos <= d) {
        const t = pos / d;
        out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
        pos += stepM;
      }
      carry = d - (pos - stepM);
    }
    const last = coords[coords.length - 1];
    if (C.haversine(out[out.length - 1], last) > 1) out.push(last);
    return out;
  };
})(typeof window !== 'undefined' ? window : globalThis);
