/* health.js — turns a scored route into a plain-language health snapshot.
 *
 * Everything here is a rough, illustrative estimate built on SIMULATED data:
 *  - AQI is converted to PM2.5 with the Indian CPCB breakpoints.
 *  - "Cigarette equivalent" uses the common rule of thumb that breathing
 *    22 µg/m³ of PM2.5 for 24 hours ≈ 1 cigarette (Berkeley Earth).
 * It is not medical advice. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  // [AQI, PM2.5 µg/m³] breakpoints (CPCB)
  const BP = [[0, 0], [50, 30], [100, 60], [200, 90], [300, 120], [400, 250], [500, 380]];

  C.pm25FromAqi = function (aqi) {
    const a = Math.max(0, Math.min(500, aqi));
    for (let i = 1; i < BP.length; i++) {
      if (a <= BP[i][0]) {
        const t = (a - BP[i - 1][0]) / (BP[i][0] - BP[i - 1][0]);
        return BP[i - 1][1] + t * (BP[i][1] - BP[i - 1][1]);
      }
    }
    return BP[BP.length - 1][1];
  };

  const LEVELS = [
    { name: 'Low', color: '#2eb872' },
    { name: 'Moderate', color: '#d9a21b' },
    { name: 'High', color: '#e8772e' },
    { name: 'Very high', color: '#d1392b' }
  ];

  function levelIndex(avgAqi, profile) {
    const cuts = profile === C.PROFILES.sensitive ? [50, 100, 200] : [100, 200, 300];
    if (avgAqi <= cuts[0]) return 0;
    if (avgAqi <= cuts[1]) return 1;
    if (avgAqi <= cuts[2]) return 2;
    return 3;
  }

  function adviceFor(idx, profile, mode) {
    const sensitive = profile === C.PROFILES.sensitive;
    const car = mode === C.MODES.car;
    const out = [];
    if (idx === 0) {
      out.push('Air along this route is mostly fine. No special precautions needed.');
      if (sensitive) out.push('Keep any reliever medication with you as usual.');
    } else if (idx === 1) {
      out.push(sensitive
        ? 'Wear a well-fitted N95 mask if you are walking or cycling.'
        : 'Fine for most people. If you have breathing problems, limit time outdoors.');
      if (car) out.push('Keep windows up and use recirculated air through busy stretches.');
    } else if (idx === 2) {
      out.push(car
        ? 'Keep windows closed and use recirculated air conditioning.'
        : 'Wear an N95 mask and keep a gentle pace to avoid breathing in more pollution.');
      out.push(sensitive
        ? 'Consider leaving at a cleaner time of day, see the departure chart.'
        : 'Check the departure chart for a cleaner time to travel.');
    } else {
      out.push('Heavy pollution along this route. Postpone or pick another time if you can.');
      out.push(car ? 'Keep windows closed and use recirculated air.' : 'Use an N95 mask and avoid exertion.');
      if (sensitive) out.push('Sensitive people should avoid this trip in these conditions.');
    }
    return out.slice(0, 3);
  }

  C.healthSummary = function (route, profile, mode) {
    let pmMin = 0, minutes = 0, poorMin = 0;
    let worst = null;
    route.segments.forEach(function (s) {
      pmMin += C.pm25FromAqi(s.aqi) * s.min;
      minutes += s.min;
      if (s.aqi > 200) poorMin += s.min;
      if (!worst || s.aqi > worst.aqi) worst = s;
    });

    const idx = levelIndex(route.avgAqi, profile);
    const cigs = (pmMin * mode.breathing) / (22 * 1440);

    let worstNear = null;
    if (worst) {
      const mid = [(worst.a[0] + worst.b[0]) / 2, (worst.a[1] + worst.b[1]) / 2];
      let best = Infinity;
      C.HOTSPOTS.forEach(function (h) {
        if (h.amp <= 0) return;
        const d = C.haversine(mid, [h.lat, h.lng]);
        if (d < best && d < 1800) { best = d; worstNear = h.name; }
      });
    }

    return {
      level: LEVELS[idx].name,
      color: LEVELS[idx].color,
      pmAvg: Math.round(minutes ? pmMin / minutes : 0),
      poorMin: Math.round(poorMin),
      cigs: cigs,
      monthly: cigs * 2 * 22, // daily round trip, 22 working days
      worstAqi: worst ? Math.round(worst.aqi) : 0,
      worstNear: worstNear,
      advice: adviceFor(idx, profile, mode)
    };
  };
})(typeof window !== 'undefined' ? window : globalThis);
