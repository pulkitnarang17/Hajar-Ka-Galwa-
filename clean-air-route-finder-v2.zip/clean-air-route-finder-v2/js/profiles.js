/* profiles.js — who is travelling and how.
 * Pure configuration: tweak numbers here to change how "sensitive" a profile is. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  C.PROFILES = {
    normal: {
      label: 'Normal',
      desc: 'Healthy adult. Air above AQI 100 starts to count against a route.',
      badThreshold: 100, // AQI above which extra penalty applies
      penalty: 0.6,      // how steeply exposure is penalised above the threshold
      tolerance: 0.15    // max extra travel time accepted for cleaner air (+15%)
    },
    sensitive: {
      label: 'Sensitive',
      desc: 'Asthma, COPD, heart conditions, elderly, children, pregnancy. Penalised from AQI 50, accepts longer detours.',
      badThreshold: 50,
      penalty: 1.6,
      tolerance: 0.4
    }
  };

  // breathing = relative amount of polluted air inhaled per minute
  // speedKmh  = fixed speed (null = use the road-network driving time)
  C.MODES = {
    car:  { label: 'Car',   breathing: 0.5, speedKmh: null },
    bike: { label: 'Cycle', breathing: 1.8, speedKmh: 15 },
    walk: { label: 'Walk',  breathing: 1.0, speedKmh: 5 }
  };
})(typeof window !== 'undefined' ? window : globalThis);
