/* map.js — everything Leaflet: base map (light/dark), live heatmap layer, hotspot markers,
 * start/end pins, route drawing and the moving trip marker. No business logic lives here. */
(function (G) {
  const C = (G.CARF = G.CARF || {});
  const L = G.L;

  const TILES = {
    light: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
  };

  let map, heat, hotLayer, routeLayer, tiles, tripMarker;
  const pins = {};

  // Heatmap: a tile layer that paints getAQI() into small canvases which the
  // browser scales up smoothly (cheap, no plugin needed).
  const CELL = 4;
  const TILE = 256;

  function paint(canvas, coords) {
    const n = TILE / CELL;
    const ctx = canvas.getContext('2d');
    const img = ctx.createImageData(n, n);
    const ox = coords.x * TILE;
    const oy = coords.y * TILE;
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const ll = map.unproject(L.point(ox + i * CELL + CELL / 2, oy + j * CELL + CELL / 2), coords.z);
        const aqi = C.getAQI(ll.lat, ll.lng);
        const rgb = C.aqiRGB(aqi);
        const o = (j * n + i) * 4;
        img.data[o] = rgb[0];
        img.data[o + 1] = rgb[1];
        img.data[o + 2] = rgb[2];
        img.data[o + 3] = 80 + Math.min(1, aqi / 300) * 100;
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  const HeatLayer = L.GridLayer.extend({
    createTile: function (coords) {
      const tile = document.createElement('canvas');
      tile.width = TILE / CELL;
      tile.height = TILE / CELL;
      paint(tile, coords);
      return tile;
    }
  });

  function pinIcon(kind) {
    return L.divIcon({
      className: '',
      html: '<div class="pin pin-' + kind + '"><span>' + (kind === 'start' ? 'A' : 'B') + '</span></div>',
      iconSize: [30, 38],
      iconAnchor: [15, 36]
    });
  }

  C.MapView = {
    init: function (id, onClick) {
      map = L.map(id, { zoomControl: false }).setView([C.CITY.lat, C.CITY.lng], C.CITY.zoom);
      L.control.zoom({ position: 'bottomright' }).addTo(map);
      tiles = L.tileLayer(TILES.light, {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        maxZoom: 19
      }).addTo(map);

      heat = new HeatLayer({ tileSize: TILE, opacity: 0.6, className: 'heat-layer' }).addTo(map);

      hotLayer = L.layerGroup();
      C.HOTSPOTS.forEach(function (h) {
        const color = h.amp > 0 ? '#c0392b' : '#1e8e5a';
        L.circleMarker([h.lat, h.lng], {
          radius: 5, color: '#fff', weight: 2, fillColor: color, fillOpacity: 1
        }).bindTooltip(h.name, { direction: 'top' }).addTo(hotLayer);
      });
      hotLayer.addTo(map);

      routeLayer = L.layerGroup().addTo(map);
      map.on('click', function (e) { onClick(e.latlng); });
      return map;
    },

    setTheme: function (dark) {
      if (!tiles) return;
      map.removeLayer(tiles);
      tiles = L.tileLayer(dark ? TILES.dark : TILES.light, {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        maxZoom: 19
      }).addTo(map);
      tiles.bringToBack();
    },

    // repaint the existing heat tiles in place (no flicker while the time slider moves)
    refreshHeat: function () {
      const t = heat._tiles;
      if (!t) { heat.redraw(); return; }
      Object.keys(t).forEach(function (k) {
        if (t[k] && t[k].el && t[k].coords) paint(t[k].el, t[k].coords);
      });
    },
    setHeat: function (on) { on ? heat.addTo(map) : map.removeLayer(heat); },
    setHotspots: function (on) { on ? hotLayer.addTo(map) : map.removeLayer(hotLayer); },
    fly: function (lat, lng, zoom) { map.flyTo([lat, lng], zoom || 14, { duration: 0.8 }); },

    setPin: function (kind, latlng, onDrag) {
      if (pins[kind]) {
        pins[kind].setLatLng(latlng);
      } else {
        pins[kind] = L.marker(latlng, { icon: pinIcon(kind), draggable: true, zIndexOffset: 1000 }).addTo(map);
        pins[kind].on('dragend', function () { onDrag(pins[kind].getLatLng()); });
      }
    },
    removePin: function (kind) {
      if (pins[kind]) { map.removeLayer(pins[kind]); delete pins[kind]; }
    },

    clearRoutes: function () { routeLayer.clearLayers(); },

    // Selected route is drawn last, coloured segment by segment by AQI.
    drawRoutes: function (routes, selected, onSelect) {
      routeLayer.clearLayers();
      routes.forEach(function (r) {
        if (r.index === selected) return;
        L.polyline(r.coords, { color: '#7b8794', weight: 5, opacity: 0.75, dashArray: '2 8', lineCap: 'round' })
          .on('click', function () { onSelect(r.index); })
          .addTo(routeLayer);
      });
      const sel = routes[selected];
      L.polyline(sel.coords, { color: '#ffffff', weight: 10, opacity: 0.95, lineCap: 'round', lineJoin: 'round' })
        .addTo(routeLayer);
      sel.segments.forEach(function (s) {
        L.polyline([s.a, s.b], { color: C.aqiColor(s.aqi), weight: 6, opacity: 1, lineCap: 'round' })
          .bindTooltip('AQI ' + Math.round(s.aqi) + ' · ' + C.aqiCategory(s.aqi), { sticky: true })
          .addTo(routeLayer);
      });
    },

    // moving marker used by the trip simulation and chart scrubbing
    setTrip: function (latlng, color) {
      if (!tripMarker) {
        tripMarker = L.marker(latlng, {
          icon: L.divIcon({ className: '', html: '<div class="trip-dot"><i></i></div>', iconSize: [26, 26], iconAnchor: [13, 13] }),
          interactive: false,
          zIndexOffset: 2000
        }).addTo(map);
      }
      tripMarker.setLatLng(latlng);
      const el = tripMarker.getElement();
      if (el) el.querySelector('i').style.background = color;
      if (!map.getBounds().pad(-0.2).contains(latlng)) map.panTo(latlng, { animate: true, duration: 0.4 });
    },
    clearTrip: function () {
      if (tripMarker) { map.removeLayer(tripMarker); tripMarker = null; }
    },

    fit: function (routes) {
      const all = [];
      routes.forEach(function (r) { all.push.apply(all, r.coords); });
      map.fitBounds(L.latLngBounds(all), { paddingTopLeft: [40, 40], paddingBottomRight: [40, 40] });
    },

    bounds: function () { return map.getBounds(); },
    invalidate: function () { map.invalidateSize(); }
  };
})(typeof window !== 'undefined' ? window : globalThis);
