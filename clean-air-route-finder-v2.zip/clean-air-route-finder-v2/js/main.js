/* main.js — wires the UI to the map, routing, scoring, chart, playback and health modules. */
(function (G) {
  const C = G.CARF;
  const $ = function (id) { return document.getElementById(id); };

  const state = {
    start: null,
    end: null,
    profile: 'normal',
    mode: 'car',
    raw: null,          // routes as fetched (before scoring)
    notice: '',
    analysis: null,
    selected: 0,
    pick: null,         // 'start' | 'end' while waiting for a map click
    token: 0,           // guards against out-of-order async responses
    speed: 1,           // trip simulation speed
    tripStarted: false
  };

  const DEMOS = {
    demo1: {
      start: { lat: 30.901, lng: 75.8073, label: 'PAU campus, Ludhiana' },
      end: { lat: 30.925, lng: 75.925, label: 'East Ludhiana' }
    },
    demo2: {
      start: { lat: 30.893, lng: 75.826, label: 'Sarabha Nagar, Ludhiana' },
      end: { lat: 30.93, lng: 75.93, label: 'North-east Ludhiana' }
    }
  };

  // ---------- helpers ----------
  function fmtTime(sec) {
    const m = Math.max(1, Math.round(sec / 60));
    if (m < 60) return m + ' min';
    return Math.floor(m / 60) + ' h ' + (m % 60) + ' min';
  }

  function setStatus(msg, kind) {
    const el = $('status');
    el.textContent = msg || '';
    el.className = 'status' + (kind ? ' ' + kind : '') + (msg ? ' show' : '');
  }

  function emptyResults() {
    $('results').innerHTML =
      '<div class="empty"><div class="empty-icon">🍃</div>' +
      '<p>Pick a start and destination to compare routes by air quality.</p>' +
      '<p class="muted">Tip: click the map, search a place, or try a demo route.</p></div>';
  }

  function clearResults() {
    stopTrip();
    state.raw = null;
    state.analysis = null;
    C.MapView.clearRoutes();
    emptyResults();
  }

  // ---------- time of day ----------
  function updateTimeUI() {
    const h = C.getHour();
    $('timeLabel').textContent = C.hourLabel(h);
    $('timePeriod').textContent = C.periodLabel(h);
    $('timeSlider').value = h;
    $('timeChip').textContent = '🕒 ' + C.hourLabel(h) + ' · ' + C.periodLabel(h);
  }

  let updatePending = false;
  function scheduleUpdate() {
    if (updatePending) return;
    updatePending = true;
    requestAnimationFrame(function () {
      updatePending = false;
      C.MapView.refreshHeat();
      if (state.raw) render(false, true);
    });
  }

  function setHour(h) {
    C.setHour(h);
    updateTimeUI();
    scheduleUpdate();
  }

  // ---------- points ----------
  function setPoint(kind, p, label, fly) {
    state[kind] = { lat: p.lat, lng: p.lng };
    $(kind + 'Input').value = label || ('Pin (' + p.lat.toFixed(4) + ', ' + p.lng.toFixed(4) + ')');
    C.MapView.setPin(kind, [p.lat, p.lng], function (ll) { setPoint(kind, ll, null, false); });
    if (fly) C.MapView.fly(p.lat, p.lng, 14);
    closeLists();
    if (state.start && state.end) run(); else clearResults();
  }

  function setPick(kind) {
    state.pick = state.pick === kind ? null : kind;
    $('startPick').classList.toggle('active', state.pick === 'start');
    $('endPick').classList.toggle('active', state.pick === 'end');
    document.body.classList.toggle('picking', !!state.pick);
    if (state.pick) setStatus('Click the map to place the ' + (kind === 'start' ? 'start' : 'destination') + '.', 'info');
    else setStatus('');
  }

  function onMapClick(ll) {
    let kind = state.pick;
    if (!kind) kind = !state.start ? 'start' : !state.end ? 'end' : null;
    if (!kind) return;
    state.pick = null;
    setPick(null);
    setPoint(kind, ll, null, false);
  }

  // ---------- place search ----------
  function closeLists() {
    $('startResults').innerHTML = '';
    $('endResults').innerHTML = '';
  }

  async function search(kind) {
    const q = $(kind + 'Input').value.trim();
    const box = $(kind + 'Results');
    if (!q) return;
    box.innerHTML = '<div class="list-note">Searching…</div>';
    try {
      const list = await C.geocode(q, C.MapView.bounds());
      box.innerHTML = '';
      if (!list.length) { box.innerHTML = '<div class="list-note">No places found.</div>'; return; }
      list.forEach(function (p) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = p.label;
        b.addEventListener('click', function () {
          setPoint(kind, p, p.label.split(',').slice(0, 2).join(','), true);
        });
        box.appendChild(b);
      });
    } catch (e) {
      box.innerHTML = '<div class="list-note">Search unavailable. Click the map instead.</div>';
    }
  }

  // ---------- routing + render ----------
  async function run() {
    if (!state.start || !state.end) { setStatus('Pick a start and a destination first.', 'warn'); return; }
    const token = ++state.token;
    stopTrip();
    $('findBtn').disabled = true;
    $('results').innerHTML = '<div class="empty"><div class="spinner"></div><p>Finding routes and sampling air quality…</p></div>';
    setStatus('');
    let notice = '';
    let raw;
    try {
      raw = await C.fetchRoutes(state.start, state.end);
    } catch (e) {
      raw = C.syntheticRoutes(state.start, state.end);
      notice = 'Routing service unreachable, so these are illustrative paths rather than real roads.';
    }
    if (token !== state.token) return;
    const mid = [(state.start.lat + state.end.lat) / 2, (state.start.lng + state.end.lng) / 2];
    if (C.haversine(mid, [C.CITY.lat, C.CITY.lng]) > 25000) {
      notice = (notice ? notice + ' ' : '') + 'This trip is outside the simulated ' + C.CITY.name + ' area, where air quality is a flat background level.';
    }
    state.raw = raw;
    state.notice = notice;
    $('findBtn').disabled = false;
    render(true, false);
  }

  function render(fit, keepSel) {
    if (!state.raw) return;
    const profile = C.PROFILES[state.profile];
    const mode = C.MODES[state.mode];
    const A = C.analyse(state.raw, profile, mode);
    state.analysis = A;
    if (!(keepSel && state.selected < A.routes.length)) state.selected = A.best.index;
    draw();
    if (fit) C.MapView.fit(A.routes);
  }

  function draw() {
    stopTrip();
    const A = state.analysis;
    C.MapView.drawRoutes(A.routes, state.selected, function (i) { state.selected = i; draw(); });
    renderResults();
  }

  // ---------- trip simulation ----------
  function stopTripVisuals() {
    $('tripHud').hidden = true;
    C.MapView.clearTrip();
    C.Chart.clearCursor();
  }

  function stopTrip() {
    C.Playback.reset(false);
    state.tripStarted = false;
    stopTripVisuals();
    syncSim();
  }

  function syncSim() {
    const btn = $('simPlay');
    if (!btn) return;
    if (C.Playback.isPlaying()) btn.textContent = '⏸ Pause';
    else if (state.tripStarted && C.Playback.isDone()) btn.textContent = '↻ Replay trip';
    else if (state.tripStarted) btn.textContent = '▶ Resume';
    else btn.textContent = '▶ Simulate trip';
  }

  function onTick(i) {
    C.MapView.setTrip(i.pos, C.aqiColor(i.aqi));
    $('tripHud').hidden = false;
    const aqiEl = $('hudAqi');
    aqiEl.textContent = Math.round(i.aqi);
    aqiEl.style.background = C.aqiColor(i.aqi);
    $('hudCat').textContent = C.aqiCategory(i.aqi);
    $('hudTime').textContent = Math.round(i.minutes) + ' / ' + Math.round(i.totalMin) + ' min';
    $('hudExp').textContent = Math.round(i.doseFrac * 100) + '% of this trip’s exposure so far';
    $('hudBar').style.width = Math.round(i.doseFrac * 100) + '%';
    C.Chart.setCursor(i.distM, i.aqi);
    if (i.done) syncSim();
  }

  function onScrub(d) {
    if (C.Playback.isPlaying()) return;
    if (d === null) {
      if (!state.tripStarted) stopTripVisuals();
      return;
    }
    C.Playback.seekDistance(d);
  }

  // ---------- results markup ----------
  function card(r, A, maxDose) {
    const tags = r.tags.map(function (t) {
      return '<span class="tag tag-' + t.toLowerCase() + '">' + t + '</span>';
    }).join('');
    const extra = r.extraMin >= 0.5 ? '<span class="extra">+' + Math.round(r.extraMin) + ' min</span>' : '';
    let exp;
    if (r === A.fastest) {
      exp = '<span class="muted">Baseline exposure</span>';
    } else if (r.savingPct >= 1) {
      exp = '<span class="good">' + Math.round(r.savingPct) + '% less exposure</span>';
    } else if (r.savingPct <= -1) {
      exp = '<span class="bad">' + Math.round(-r.savingPct) + '% more exposure</span>';
    } else {
      exp = '<span class="muted">Similar exposure</span>';
    }
    return '<button type="button" class="route' + (r.index === state.selected ? ' selected' : '') + '" data-i="' + r.index + '">' +
      '<div class="route-top"><span class="route-name">Route ' + (r.index + 1) + '</span>' + tags + '</div>' +
      '<div class="route-meta"><b>' + fmtTime(r.duration) + '</b><span>' + (r.distance / 1000).toFixed(1) + ' km</span>' + extra + '</div>' +
      '<div class="route-air"><span class="dot" style="background:' + C.aqiColor(r.avgAqi) + '"></span>' +
      'Avg AQI <b>' + Math.round(r.avgAqi) + '</b> · ' + C.aqiCategory(r.avgAqi) +
      '<span class="spacer"></span>Peak <b>' + Math.round(r.peakAqi) + '</b></div>' +
      '<div class="route-exp">' + exp + '</div>' +
      '<div class="bar"><i style="width:' + Math.max(6, (r.dose / maxDose) * 100) + '%;background:' + C.aqiColor(r.avgAqi) + '"></i></div>' +
      '</button>';
  }

  function healthHtml(sel, profile, mode) {
    const h = C.healthSummary(sel, profile, mode);
    const cigs = h.cigs < 0.1 ? '<0.1' : h.cigs.toFixed(1);
    const monthly = h.monthly < 10 ? h.monthly.toFixed(1) : String(Math.round(h.monthly));
    const worst = h.worstNear
      ? '<p class="worst">Worst stretch: AQI ' + h.worstAqi + ' near ' + h.worstNear + '.</p>'
      : '<p class="worst">Worst stretch: AQI ' + h.worstAqi + '.</p>';
    return '<div class="health">' +
      '<div class="health-head"><h3>Health snapshot · Route ' + (sel.index + 1) + '</h3>' +
      '<span class="level" style="background:' + h.color + '">' + h.level + ' exposure</span></div>' +
      '<div class="stats">' +
      '<div><b>' + h.pmAvg + '</b><span>avg PM2.5 (µg/m³)</span></div>' +
      '<div><b>' + h.poorMin + '</b><span>min in Poor air</span></div>' +
      '<div><b>' + cigs + '</b><span>cigarette-equivalent</span></div></div>' +
      '<p class="cig-line">As a daily round trip, that is about <b>' + monthly + '</b> cigarettes’ worth of PM2.5 a month.</p>' +
      worst +
      '<ul class="advice">' + h.advice.map(function (a) { return '<li>' + a + '</li>'; }).join('') + '</ul>' +
      '<p class="fine">Rough estimate from simulated data (22 µg/m³ for 24 h ≈ 1 cigarette). Not medical advice.</p>' +
      '</div>';
  }

  function departHtml(sel, profile, mode) {
    const doses = C.hourlyDose(sel, profile, mode);
    const cur = Math.floor(C.getHour());
    let min = Infinity, max = -Infinity, bestH = 0;
    doses.forEach(function (d, h) {
      if (d < min) { min = d; bestH = h; }
      if (d > max) max = d;
    });
    const pct = Math.round((1 - doses[bestH] / doses[cur]) * 100);
    let text;
    if (max / min < 1.04) {
      text = 'Exposure barely changes through the day on this route.';
    } else if (bestH === cur) {
      text = 'Now is already the cleanest hour to leave.';
    } else if (pct < 3) {
      text = 'Your chosen time is already close to the cleanest (' + C.hourLabel(bestH) + ').';
    } else {
      text = 'Leave at <b>' + C.hourLabel(bestH) + '</b> instead of ' + C.hourLabel(cur) +
        ' to cut exposure by <b>' + pct + '%</b>.';
    }
    const bars = doses.map(function (d, h) {
      const t = max > min ? (d - min) / (max - min) : 0.4;
      const rel = Math.round((d / doses[cur] - 1) * 100);
      const relText = h === cur ? 'selected time' : (rel > 0 ? '+' + rel + '% vs selected' : rel + '% vs selected');
      return '<button type="button" class="depart-bar' + (h === cur ? ' now' : '') + (h === bestH ? ' best' : '') +
        '" data-h="' + h + '" style="height:' + Math.round(18 + t * 82) + '%;background:' + C.aqiColor(40 + t * 260) +
        '" title="' + C.hourLabel(h) + ' · ' + relText + '"></button>';
    }).join('');
    return '<div class="depart"><div class="card-head"><h3>Best time to leave</h3></div>' +
      '<p class="depart-text">' + text + '</p>' +
      '<div class="depart-bars">' + bars + '</div>' +
      '<div class="depart-scale"><span>12 am</span><span>6 am</span><span>12 pm</span><span>6 pm</span><span>11 pm</span></div>' +
      '<div class="depart-key"><span class="key-now">Selected</span><span class="key-best">Cleanest</span><span>Tap a bar to travel then</span></div>' +
      '</div>';
  }

  function renderResults() {
    const A = state.analysis;
    const profile = C.PROFILES[state.profile];
    const mode = C.MODES[state.mode];
    const maxDose = Math.max.apply(null, A.routes.map(function (r) { return r.dose; }));
    const b = A.best;
    const sel = A.routes[state.selected];

    let summary;
    if (b === A.fastest) {
      summary = 'The fastest route is also the cleanest option for a <b>' + profile.label.toLowerCase() +
        '</b> traveller. Average AQI ' + Math.round(b.avgAqi) + '.';
    } else {
      summary = '<b>Route ' + (b.index + 1) + '</b> adds ' + Math.round(b.extraMin) + ' min but cuts your pollution exposure by <b>' +
        Math.round(b.savingPct) + '%</b>.';
    }

    const warns = C.warningsFor(sel, profile, mode);
    const warnHtml = warns.length
      ? '<div class="warn"><h3>Heads-up for Route ' + (sel.index + 1) + '</h3><ul>' +
        warns.map(function (w) { return '<li>' + w + '</li>'; }).join('') + '</ul></div>'
      : '<div class="warn ok"><h3>Route ' + (sel.index + 1) + '</h3><p>No major pollution hotspots along this route.</p></div>';

    const speeds = [1, 2, 4].map(function (s) {
      return '<option value="' + s + '"' + (s === state.speed ? ' selected' : '') + '>' + s + '×</option>';
    }).join('');

    $('results').innerHTML =
      (state.notice ? '<div class="notice">' + state.notice + '</div>' : '') +
      '<div class="summary"><div class="summary-icon">✓</div><p>' + summary + '</p></div>' +
      '<div class="routes">' + A.routes.map(function (r) { return card(r, A, maxDose); }).join('') + '</div>' +
      '<div class="sim"><button type="button" class="btn primary sm" id="simPlay">▶ Simulate trip</button>' +
      '<button type="button" class="btn ghost sm" id="simReset">Reset</button>' +
      '<select id="simSpeed" aria-label="Simulation speed">' + speeds + '</select></div>' +
      C.Chart.render(A, state.selected, profile) +
      healthHtml(sel, profile, mode) +
      departHtml(sel, profile, mode) +
      warnHtml;

    C.Chart.bind($('results'), onScrub);
    C.Playback.load(sel, onTick);
    C.Playback.setSpeed(state.speed);
    syncSim();
  }

  // ---------- theme ----------
  function applyTheme(dark) {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    C.MapView.setTheme(dark);
    try { localStorage.setItem('carf_theme', dark ? 'dark' : 'light'); } catch (e) { /* ignore */ }
  }

  // ---------- controls ----------
  function bindSeg(id, key, onChange) {
    $(id).addEventListener('click', function (e) {
      const btn = e.target.closest('button[data-value]');
      if (!btn) return;
      state[key] = btn.dataset.value;
      Array.prototype.forEach.call($(id).querySelectorAll('button'), function (b) {
        b.setAttribute('aria-pressed', String(b === btn));
      });
      if (onChange) onChange();
      if (state.raw) render(false, false);
    });
  }

  function init() {
    const now = new Date();
    C.setHour(now.getHours() + (now.getMinutes() >= 30 ? 0.5 : 0));
    updateTimeUI();

    C.MapView.init('map', onMapClick);
    if (document.documentElement.getAttribute('data-theme') === 'dark') C.MapView.setTheme(true);
    emptyResults();

    bindSeg('profileSeg', 'profile', function () {
      $('profileDesc').textContent = C.PROFILES[state.profile].desc;
    });
    bindSeg('modeSeg', 'mode');
    $('profileDesc').textContent = C.PROFILES[state.profile].desc;

    $('timeSlider').addEventListener('input', function (e) { setHour(parseFloat(e.target.value)); });
    $('timeNow').addEventListener('click', function () {
      const n = new Date();
      setHour(n.getHours() + (n.getMinutes() >= 30 ? 0.5 : 0));
    });
    $('scenarioSel').addEventListener('change', function (e) {
      C.setScenario(e.target.value);
      scheduleUpdate();
    });
    $('heatToggle').addEventListener('change', function (e) { C.MapView.setHeat(e.target.checked); });
    $('hotToggle').addEventListener('change', function (e) { C.MapView.setHotspots(e.target.checked); });

    $('themeBtn').addEventListener('click', function () {
      applyTheme(document.documentElement.getAttribute('data-theme') !== 'dark');
    });
    $('tourBtn').addEventListener('click', function () { C.Tour.start(); });

    ['start', 'end'].forEach(function (kind) {
      $(kind + 'Input').addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); search(kind); }
      });
      $(kind + 'Search').addEventListener('click', function () { search(kind); });
      $(kind + 'Pick').addEventListener('click', function () { setPick(kind); });
    });
    document.addEventListener('click', function (e) {
      if (!e.target.closest('.field')) closeLists();
    });

    $('findBtn').addEventListener('click', run);
    $('clearBtn').addEventListener('click', function () {
      ['start', 'end'].forEach(function (k) {
        state[k] = null;
        $(k + 'Input').value = '';
        C.MapView.removePin(k);
      });
      state.token++;
      setPick(null);
      setStatus('');
      clearResults();
    });

    ['demo1', 'demo2'].forEach(function (id) {
      $(id).addEventListener('click', function () {
        const d = DEMOS[id];
        state.start = { lat: d.start.lat, lng: d.start.lng };
        C.MapView.setPin('start', [d.start.lat, d.start.lng], function (ll) { setPoint('start', ll, null, false); });
        $('startInput').value = d.start.label;
        setPoint('end', d.end, d.end.label, false);
      });
    });

    // one delegated listener for everything inside the results panel
    $('results').addEventListener('click', function (e) {
      const routeBtn = e.target.closest('.route');
      if (routeBtn) {
        state.selected = parseInt(routeBtn.dataset.i, 10);
        draw();
        return;
      }
      if (e.target.closest('#simPlay')) {
        if (C.Playback.isPlaying()) {
          C.Playback.pause();
        } else {
          state.tripStarted = true;
          C.Playback.setSpeed(state.speed);
          C.Playback.play();
        }
        syncSim();
        return;
      }
      if (e.target.closest('#simReset')) { stopTrip(); return; }
      const bar = e.target.closest('.depart-bar');
      if (bar) setHour(parseInt(bar.dataset.h, 10));
    });
    $('results').addEventListener('change', function (e) {
      if (e.target.id === 'simSpeed') {
        state.speed = parseFloat(e.target.value);
        C.Playback.setSpeed(state.speed);
      }
    });

    window.addEventListener('resize', function () { C.MapView.invalidate(); });

    if (C.Tour.shouldAutoStart()) setTimeout(function () { C.Tour.start(); }, 900);
  }

  document.addEventListener('DOMContentLoaded', init);
})(window);
