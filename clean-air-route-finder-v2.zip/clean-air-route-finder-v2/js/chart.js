/* chart.js — SVG chart of AQI against distance for every route.
 * The selected route is drawn in AQI colours; the others in grey.
 * render() returns an HTML string; bind() wires hover/touch scrubbing;
 * setCursor()/clearCursor() move the marker without redrawing. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  const W = 340, H = 168;
  const M = { l: 34, r: 10, t: 12, b: 24 };
  const BANDS = [
    [0, 50, '#2eb872'], [50, 100, '#7ccf5b'], [100, 200, '#f2c94c'],
    [200, 300, '#f2994a'], [300, 400, '#e0432f'], [400, 500, '#9b2548']
  ];
  let geo = null;

  const f1 = function (n) { return n.toFixed(1); };
  const len = function (r) { return r.segments.reduce(function (a, s) { return a + s.len; }, 0); };

  // stepped profile: one point per segment midpoint, plus both ends
  function pts(route) {
    const out = [];
    let d = 0;
    route.segments.forEach(function (s) { out.push([d + s.len / 2, s.aqi]); d += s.len; });
    if (!out.length) return out;
    out.unshift([0, out[0][1]]);
    out.push([d, out[out.length - 1][1]]);
    return out;
  }

  function render(A, sel, profile) {
    const routes = A.routes;
    const maxD = Math.max.apply(null, routes.map(len));
    const peak = Math.max.apply(null, routes.map(function (r) { return r.peakAqi; }));
    const yMax = Math.max(200, Math.ceil((peak * 1.08) / 100) * 100);
    const pw = W - M.l - M.r;
    const ph = H - M.t - M.b;
    const X = function (d) { return M.l + (d / maxD) * pw; };
    const Y = function (a) { return M.t + ph - (Math.min(a, yMax) / yMax) * ph; };
    const selR = routes[sel];
    const selLen = len(selR);
    geo = { maxD: maxD, yMax: yMax, X: X, Y: Y, selLen: selLen, pw: pw, ph: ph };

    let svg = '';

    BANDS.forEach(function (b) {
      if (b[0] >= yMax) return;
      const top = Y(Math.min(b[1], yMax));
      const bot = Y(b[0]);
      svg += '<rect x="' + M.l + '" y="' + f1(top) + '" width="' + pw + '" height="' + f1(bot - top) +
        '" fill="' + b[2] + '" opacity="0.11"/>';
    });

    for (let v = 0; v <= yMax; v += 100) {
      svg += '<line class="c-grid" x1="' + M.l + '" x2="' + (W - M.r) + '" y1="' + f1(Y(v)) + '" y2="' + f1(Y(v)) + '"/>' +
        '<text class="c-axis" x="' + (M.l - 5) + '" y="' + f1(Y(v) + 3) + '" text-anchor="end">' + v + '</text>';
    }
    const km = maxD / 1000;
    const step = km <= 4 ? 1 : km <= 10 ? 2 : 5;
    for (let k = 0; k * 1000 <= maxD; k += step) {
      const x = X(k * 1000);
      svg += '<line class="c-grid" x1="' + f1(x) + '" x2="' + f1(x) + '" y1="' + M.t + '" y2="' + (M.t + ph) + '"/>' +
        '<text class="c-axis" x="' + f1(x) + '" y="' + (H - 9) + '" text-anchor="middle">' + k + '</text>';
    }
    svg += '<text class="c-axis" x="' + (W - M.r) + '" y="' + (H - 9) + '" text-anchor="end">km</text>';

    routes.forEach(function (r) {
      if (r.index === sel) return;
      svg += '<polyline class="c-other" points="' +
        pts(r).map(function (p) { return f1(X(p[0])) + ',' + f1(Y(p[1])); }).join(' ') + '"/>';
    });

    const sp = pts(selR);
    const every = Math.max(1, Math.ceil(sp.length / 60));
    let stops = '';
    sp.forEach(function (p, i) {
      if (i % every === 0 || i === sp.length - 1) {
        stops += '<stop offset="' + Math.min(1, p[0] / selLen).toFixed(3) + '" stop-color="' + C.aqiColor(p[1]) + '"/>';
      }
    });
    const line = sp.map(function (p) { return f1(X(p[0])) + ',' + f1(Y(p[1])); }).join(' ');
    svg = '<defs><linearGradient id="cg" gradientUnits="userSpaceOnUse" x1="' + f1(X(0)) + '" x2="' + f1(X(selLen)) +
      '" y1="0" y2="0">' + stops + '</linearGradient></defs>' + svg;
    svg += '<path d="M' + f1(X(0)) + ',' + f1(Y(0)) + ' L' + line.replace(/ /g, ' L') + ' L' + f1(X(selLen)) + ',' + f1(Y(0)) +
      ' Z" fill="url(#cg)" opacity="0.2"/>';
    svg += '<polyline points="' + line + '" fill="none" stroke="url(#cg)" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/>';

    if (profile.badThreshold < yMax) {
      const ty = Y(profile.badThreshold);
      svg += '<line class="c-thr" x1="' + M.l + '" x2="' + (W - M.r) + '" y1="' + f1(ty) + '" y2="' + f1(ty) + '"/>' +
        '<text class="c-thr-label" x="' + (W - M.r - 2) + '" y="' + f1(ty - 3) + '" text-anchor="end">comfort limit ' + profile.badThreshold + '</text>';
    }

    svg += '<g id="chartCursor" style="display:none;pointer-events:none">' +
      '<line id="ccLine" class="c-cursor" x1="0" x2="0" y1="' + M.t + '" y2="' + (M.t + ph) + '"/>' +
      '<circle id="ccDot" r="5" cx="0" cy="0" stroke="#fff" stroke-width="2"/></g>';

    return '<div class="chart-card">' +
      '<div class="card-head"><h3>Air quality along the route</h3><span id="chartReadout" class="readout">Hover or tap to inspect</span></div>' +
      '<svg id="aqiChart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="AQI against distance for each route">' + svg + '</svg>' +
      '<div class="chart-note">Selected route coloured by AQI · other routes in grey</div></div>';
  }

  function bind(root, onScrub) {
    const svg = root.querySelector('#aqiChart');
    if (!svg || !geo) return;
    function dist(e) {
      const r = svg.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width) * W;
      const d = ((x - M.l) / geo.pw) * geo.maxD;
      return Math.min(geo.selLen, Math.max(0, d));
    }
    svg.addEventListener('pointermove', function (e) { onScrub(dist(e)); });
    svg.addEventListener('pointerdown', function (e) { onScrub(dist(e)); });
    svg.addEventListener('pointerleave', function () { onScrub(null); });
  }

  function setCursor(d, aqi) {
    if (!geo) return;
    const g = document.getElementById('chartCursor');
    if (!g) return;
    const x = geo.X(d);
    const line = document.getElementById('ccLine');
    const dot = document.getElementById('ccDot');
    line.setAttribute('x1', f1(x)); line.setAttribute('x2', f1(x));
    dot.setAttribute('cx', f1(x)); dot.setAttribute('cy', f1(geo.Y(aqi)));
    dot.setAttribute('fill', C.aqiColor(aqi));
    g.style.display = 'block';
    const ro = document.getElementById('chartReadout');
    if (ro) ro.textContent = 'AQI ' + Math.round(aqi) + ' · ' + C.aqiCategory(aqi) + ' · ' + (d / 1000).toFixed(1) + ' km';
  }

  function clearCursor() {
    const g = document.getElementById('chartCursor');
    if (g) g.style.display = 'none';
    const ro = document.getElementById('chartReadout');
    if (ro) ro.textContent = 'Hover or tap to inspect';
  }

  C.Chart = { render: render, bind: bind, setCursor: setCursor, clearCursor: clearCursor };
})(typeof window !== 'undefined' ? window : globalThis);
