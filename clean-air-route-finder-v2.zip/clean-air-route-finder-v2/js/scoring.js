/* scoring.js — turns candidate routes into exposure scores and a recommendation.
 *
 * For every ~150 m segment of a route:
 *   aqi       = getAQI at the segment midpoint (at the current time of day)
 *   minutes   = time spent on that segment
 *   effective = aqi, penalised more steeply once it passes the profile's threshold
 *   dose     += effective * minutes * breathing-rate(mode)
 * Lower total dose = cleaner trip. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  C.scoreRoute = function (route, profile, mode) {
    const pts = C.resample(route.coords, 150);
    const mps = route.distance / route.duration;
    const segments = [];
    let totalMin = 0, aqiMin = 0, dose = 0, peak = 0, poorLen = 0, len = 0;

    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1];
      const b = pts[i];
      const l = C.haversine(a, b);
      if (l < 1) continue;
      const aqi = C.getAQI((a[0] + b[0]) / 2, (a[1] + b[1]) / 2);
      const min = l / mps / 60;
      const effective = aqi * (1 + profile.penalty * Math.max(0, (aqi - profile.badThreshold) / 100));
      const segDose = effective * min * mode.breathing;
      dose += segDose;
      totalMin += min;
      aqiMin += aqi * min;
      len += l;
      if (aqi > 200) poorLen += l;
      if (aqi > peak) peak = aqi;
      segments.push({ a, b, aqi, len: l, min, dose: segDose });
    }

    return Object.assign({}, route, {
      segments,
      avgAqi: totalMin ? aqiMin / totalMin : 0,
      peakAqi: peak,
      poorShare: len ? poorLen / len : 0,
      dose
    });
  };

  // Score every route, rank them, and pick the recommendation.
  C.analyse = function (rawRoutes, profile, mode) {
    const routes = rawRoutes.map(function (r) {
      const duration = mode.speedKmh ? r.distance / (mode.speedKmh / 3.6) : r.duration;
      return C.scoreRoute(Object.assign({}, r, { duration: duration }), profile, mode);
    });
    routes.sort(function (x, y) { return x.duration - y.duration; });
    routes.forEach(function (r, i) { r.index = i; r.tags = []; });

    const fastest = routes[0];
    const allowed = routes.filter(function (r) {
      return r.duration <= fastest.duration * (1 + profile.tolerance) + 30;
    });
    const best = allowed.reduce(function (m, r) { return r.dose < m.dose ? r : m; }, allowed[0]);
    const cleanest = routes.reduce(function (m, r) { return r.dose < m.dose ? r : m; }, routes[0]);

    routes.forEach(function (r) {
      r.savingPct = fastest.dose ? (1 - r.dose / fastest.dose) * 100 : 0;
      r.extraMin = (r.duration - fastest.duration) / 60;
    });

    if (best === fastest) {
      fastest.tags.push('Recommended', 'Fastest');
    } else {
      fastest.tags.push('Fastest');
      best.tags.push('Recommended');
    }
    if (cleanest !== best) cleanest.tags.push('Cleanest');

    return {
      routes: routes,
      fastest: fastest,
      best: best,
      cleanest: cleanest,
      warnings: C.warningsFor(best, profile, mode)
    };
  };

  // Exposure of one route if you left at each hour of the day (24 values).
  C.hourlyDose = function (route, profile, mode) {
    const keep = C.getHour();
    const out = [];
    for (let h = 0; h < 24; h++) {
      C.setHour(h);
      out.push(C.scoreRoute(route, profile, mode).dose);
    }
    C.setHour(keep);
    return out;
  };

  // Human-readable heads-ups for a route.
  C.warningsFor = function (route, profile, mode) {
    const out = [];
    const near = [];
    C.HOTSPOTS.forEach(function (h) {
      if (h.amp <= 0) return;
      const aqi = C.getAQI(h.lat, h.lng);
      if (aqi < 180) return;
      let d = Infinity;
      route.segments.forEach(function (s) {
        d = Math.min(d, C.haversine(s.a, [h.lat, h.lng]));
      });
      if (d < 800) near.push({ h: h, d: d, aqi: aqi });
    });
    near.sort(function (x, y) { return x.d - y.d; });
    near.slice(0, 3).forEach(function (n) {
      out.push('Passes within ~' + (Math.max(1, Math.round(n.d / 100)) * 100) + ' m of ' +
        n.h.name + ' (AQI ≈ ' + Math.round(n.aqi) + ').');
    });

    if (route.poorShare > 0.05) {
      out.push(Math.round(route.poorShare * 100) + '% of this route is in Poor air (AQI above 200).');
    }
    if (profile === C.PROFILES.sensitive && route.avgAqi > 100) {
      out.push('Consider an N95 mask and keep inhalers or medication handy.');
    }
    if ((mode === C.MODES.bike || mode === C.MODES.walk) && route.avgAqi > 150) {
      out.push('Strenuous travel in this air increases inhaled pollution — a car or a later time may be better.');
    }
    return out;
  };
})(typeof window !== 'undefined' ? window : globalThis);
