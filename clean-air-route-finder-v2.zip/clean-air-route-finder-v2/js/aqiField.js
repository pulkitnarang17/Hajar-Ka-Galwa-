/* aqiField.js — the simulated pollution surface (v2: now varies with time of day).
 *
 * getAQI(lat, lng) is the ONLY thing the rest of the app needs for pollution data.
 * To merge with the main AQI simulator later, re-implement getAQI() on top of it
 * (or point it at a real API) — nothing else has to change.
 *
 * Model: AQI = base(scenario, hour) + sum of gaussian "blobs".
 * Hotspots raise it, green zones lower it, and each hotspot type follows its own
 * daily rhythm (traffic peaks at rush hour, industry in the daytime, markets in the evening).
 * Locations are approximate / illustrative, centred on Ludhiana, Punjab. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  C.CITY = { name: 'Ludhiana', lat: 30.9, lng: 75.86, zoom: 12 };

  // type: 'industrial' | 'traffic' | 'market' | 'green'
  // amp = AQI added at the centre, sigma = spread in km
  C.HOTSPOTS = [
    { name: 'Focal Point industrial area', type: 'industrial', lat: 30.885, lng: 75.925, amp: 190, sigma: 1.6 },
    { name: 'Giaspura industrial cluster', type: 'industrial', lat: 30.863, lng: 75.9, amp: 150, sigma: 1.3 },
    { name: 'Tajpur Road dyeing cluster', type: 'industrial', lat: 30.878, lng: 75.865, amp: 140, sigma: 1.2 },
    { name: 'Clock Tower / Chaura Bazaar', type: 'market', lat: 30.9138, lng: 75.8573, amp: 110, sigma: 0.9 },
    { name: 'Bus stand & railway station', type: 'traffic', lat: 30.902, lng: 75.865, amp: 90, sigma: 0.8 },
    { name: 'Samrala Chowk', type: 'traffic', lat: 30.897, lng: 75.883, amp: 100, sigma: 0.9 },
    { name: 'Jalandhar Bypass / Sherpur Chowk', type: 'traffic', lat: 30.9, lng: 75.91, amp: 110, sigma: 1.0 },
    { name: 'PAU campus', type: 'green', lat: 30.901, lng: 75.807, amp: -60, sigma: 1.5 },
    { name: 'Rakh Bagh park', type: 'green', lat: 30.9185, lng: 75.846, amp: -35, sigma: 0.5 },
    { name: 'Sarabha Nagar green belt', type: 'green', lat: 30.893, lng: 75.826, amp: -30, sigma: 0.8 }
  ];

  // base = background AQI everywhere, scale = how strongly hotspots show
  C.SCENARIOS = {
    typical: { label: 'Typical day', base: 75, scale: 1.0 },
    smog:    { label: 'Smog / stubble-burning season', base: 150, scale: 1.25 },
    clean:   { label: 'Clean day (after rain)', base: 45, scale: 0.55 }
  };

  let scenario = C.SCENARIOS.typical;
  C.setScenario = function (key) { scenario = C.SCENARIOS[key] || C.SCENARIOS.typical; };

  // ---------- time of day ----------
  // circular gaussian bump on a 24 h clock
  function bump(h, mu, sd) {
    let d = Math.abs(h - mu);
    d = Math.min(d, 24 - d);
    return Math.exp(-(d * d) / (2 * sd * sd));
  }

  function factorsFor(h) {
    return {
      // background air is worst around night / early morning (cool, still air), best mid-afternoon
      base: 1 + 0.15 * Math.cos(((h - 2) / 24) * 2 * Math.PI),
      traffic: Math.min(1.4, 0.55 + 0.75 * (bump(h, 9, 1.6) + bump(h, 18.5, 2)) + 0.25 * bump(h, 13.5, 3.5)),
      industrial: 0.7 + 0.3 * bump(h, 13, 5),
      market: Math.min(1.1, 0.35 + 0.75 * bump(h, 16, 4.5)),
      green: 1
    };
  }

  let hour = 12;
  let factors = factorsFor(hour);

  C.setHour = function (h) {
    hour = ((h % 24) + 24) % 24;
    factors = factorsFor(hour);
  };
  C.getHour = function () { return hour; };

  C.hourLabel = function (h) {
    const hh = Math.floor(h) % 24;
    const mm = Math.round((h - Math.floor(h)) * 60);
    const h12 = hh % 12 || 12;
    return h12 + ':' + (mm < 10 ? '0' : '') + mm + ' ' + (hh < 12 ? 'am' : 'pm');
  };

  C.periodLabel = function (h) {
    if (h < 5) return 'Night';
    if (h < 7) return 'Early morning';
    if (h < 11) return 'Morning rush';
    if (h < 16) return 'Daytime';
    if (h < 20) return 'Evening rush';
    return 'Night';
  };

  const rad = Math.PI / 180;

  C.getAQI = function (lat, lng) {
    let v = scenario.base * factors.base;
    for (const h of C.HOTSPOTS) {
      const dy = (lat - h.lat) * 111.32;
      const dx = (lng - h.lng) * 111.32 * Math.cos(lat * rad);
      const d2 = dx * dx + dy * dy;
      v += h.amp * scenario.scale * (factors[h.type] || 1) * Math.exp(-d2 / (2 * h.sigma * h.sigma));
    }
    // small fixed texture so the field doesn't look perfectly smooth
    v += 5 * Math.sin(lat * 900) * Math.cos(lng * 800);
    return Math.max(20, Math.min(500, v));
  };

  // ---------- colours & categories (Indian CPCB bands) ----------
  const STOPS = [
    [0, [46, 184, 114]],
    [50, [124, 207, 91]],
    [100, [242, 201, 76]],
    [200, [242, 153, 74]],
    [300, [224, 67, 47]],
    [400, [155, 37, 72]],
    [500, [91, 26, 58]]
  ];

  C.aqiRGB = function (aqi) {
    const a = Math.max(0, Math.min(500, aqi));
    for (let i = 1; i < STOPS.length; i++) {
      if (a <= STOPS[i][0]) {
        const [a0, c0] = STOPS[i - 1];
        const [a1, c1] = STOPS[i];
        const t = (a - a0) / (a1 - a0);
        return c0.map((v, k) => Math.round(v + (c1[k] - v) * t));
      }
    }
    return STOPS[STOPS.length - 1][1];
  };

  C.aqiColor = function (aqi) {
    const c = C.aqiRGB(aqi);
    return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
  };

  C.aqiCategory = function (aqi) {
    if (aqi <= 50) return 'Good';
    if (aqi <= 100) return 'Satisfactory';
    if (aqi <= 200) return 'Moderate';
    if (aqi <= 300) return 'Poor';
    if (aqi <= 400) return 'Very poor';
    return 'Severe';
  };
})(typeof window !== 'undefined' ? window : globalThis);
