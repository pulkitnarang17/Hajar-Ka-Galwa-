/* playback.js — animates a trip along the selected route.
 * Emits {pos, aqi, minutes, totalMin, distM, totalDist, doseFrac, done} on every step,
 * so the UI can move a marker, update the HUD and the chart cursor. */
(function (G) {
  const C = (G.CARF = G.CARF || {});

  const BASE_MS = 14000; // whole trip takes ~14 s at 1×
  let cum = [], total = 0, totalDist = 0, totalDose = 0;
  let route = null, cb = null;
  let p = 0, playing = false, last = 0, speed = 1, raf = 0;

  function build(r) {
    cum = [];
    let t = 0, d = 0, x = 0;
    r.segments.forEach(function (s) {
      cum.push({ t0: t, t1: t + s.min, d0: d, d1: d + s.len, x0: x, x1: x + s.dose, s: s });
      t += s.min; d += s.len; x += s.dose;
    });
    total = t; totalDist = d; totalDose = x;
  }

  function find(key, value) {
    let lo = 0, hi = cum.length - 1;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (cum[mid][key + '1'] < value) lo = mid + 1; else hi = mid;
    }
    return cum[lo];
  }

  function emit() {
    if (!cum.length) return;
    const t = p * total;
    const c = find('t', t);
    const f = c.t1 > c.t0 ? Math.min(1, Math.max(0, (t - c.t0) / (c.t1 - c.t0))) : 0;
    const s = c.s;
    if (cb) {
      cb({
        pos: [s.a[0] + (s.b[0] - s.a[0]) * f, s.a[1] + (s.b[1] - s.a[1]) * f],
        aqi: s.aqi,
        minutes: t,
        totalMin: total,
        distM: c.d0 + (c.d1 - c.d0) * f,
        totalDist: totalDist,
        doseFrac: totalDose ? (c.x0 + (c.x1 - c.x0) * f) / totalDose : 0,
        done: p >= 1
      });
    }
  }

  function frame(ts) {
    if (!playing) return;
    const dt = ts - last;
    last = ts;
    p = Math.min(1, p + (dt * speed) / BASE_MS);
    emit();
    if (p >= 1) { playing = false; return; }
    raf = requestAnimationFrame(frame);
  }

  C.Playback = {
    load: function (r, callback) {
      this.reset(false);
      route = r;
      cb = callback;
      build(r);
    },
    play: function () {
      if (!route) return;
      if (p >= 1) p = 0;
      playing = true;
      last = performance.now();
      raf = requestAnimationFrame(frame);
    },
    pause: function () { playing = false; cancelAnimationFrame(raf); },
    toggle: function () { if (playing) this.pause(); else this.play(); },
    reset: function (doEmit) {
      this.pause();
      p = 0;
      if (doEmit && route) emit();
    },
    setSpeed: function (x) { speed = x; },
    isPlaying: function () { return playing; },
    isDone: function () { return p >= 1; },
    seekDistance: function (d) {
      if (!cum.length) return;
      const c = find('d', Math.min(totalDist, Math.max(0, d)));
      const f = c.d1 > c.d0 ? (Math.min(totalDist, Math.max(0, d)) - c.d0) / (c.d1 - c.d0) : 0;
      p = total ? (c.t0 + (c.t1 - c.t0) * Math.min(1, Math.max(0, f))) / total : 0;
      emit();
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
